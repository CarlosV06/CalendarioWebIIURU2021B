package helpers;

import java.io.*;
import java.sql.*;
import java.util.ArrayList;

public class BaseD {

	public static BaseD BD = new BaseD();
	//private ProperR a = new ProperR();
	private Connection Conexion;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	//CONSTRUCTOR
	public BaseD() {
		try {
				Class.forName("org.postgresql.Driver");
				this.Conexion = DriverManager.getConnection("jdbc:postgresql://ec2-3-233-7-12.compute-1.amazonaws.com:5432/d27bco0l4e9ln", "ydzkqhniexilfr", 
						"034203e134820ba122314287066cb4271d6f2e630b819eb9991239bbcadc1fef");
				System.out.println("Conexi�n establecida exitosamente.");
	} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
		}
	}
	
	//M�TODO PARA RETORNAR LA CLAVE DEL USUARIO
	public String getClave(String Email, String Query) {
		String RespuestaBD = "";
		try {
			this.stmt = this.Conexion.createStatement();
			this.rs = this.stmt.executeQuery(Query);
			while(rs.next()) {
				String U = rs.getString("email");
				if(U.contentEquals(Email)){
					RespuestaBD = rs.getString("Pass");
				}			
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return RespuestaBD;
		
	}
	
	
	
	
	
	
	
	
	
	//A�ADIR USUARIOS A LA BD
	
	public void dbPrepareStatement(String query, Object[] obj) {
		try {
			this.pstmt = this.Conexion.prepareStatement(query);
			this.pstmt.setString(1, (String) obj[0]);
			this.pstmt.setString(2, (String) obj[1]);
			this.pstmt.setString(3, (String) obj[2]);
			this.pstmt.setString(4, (String) obj[3]);
			this.pstmt.executeUpdate();
		} catch (SQLException e) {
				e.printStackTrace();
		} finally {
			try {
				this.pstmt.close();
		} catch (SQLException e) {
				e.printStackTrace();
	 }
   }
}
	
	
	public void dbClose() {
		try {
		this.Conexion.close();
		System.out.println("Conexion cerrada");
		} catch (SQLException e) {
		e.printStackTrace();
		}
		} 
	
	
	public static BaseD getInstances() {
		return BD;
	}
	
	
	//OBTENER ID PARA EL CALENDARIO
	
	public int getID() {
		int ID = 1;
		try {
			this.stmt = this.Conexion.createStatement();
			this.rs = this.stmt.executeQuery("SELECT MAX(IDCalendario) FROM Calendario");
			while(rs.next()) {
				ID = rs.getInt(1)+1;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				this.stmt.close();
				this.rs.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
		return ID;
		
	}
	
	//AGREGAR UN CALENDARIO A LA BD
	
	public void NuevoCalendario(Object[] obj) {
		try {
			this.pstmt = this.Conexion.prepareStatement("INSERT INTO Calendario VALUES(?,?, ?)");
			this.pstmt.setInt(1, (int) obj[0]);
			this.pstmt.setString(2, (String) obj[1]);
			this.pstmt.setString(3, (String) obj[2]);
			this.pstmt.executeUpdate();
		} catch (SQLException e) {
				e.printStackTrace();
		} finally {
			try {
				this.pstmt.close();
		} catch (SQLException e) {
				e.printStackTrace();
	 }
   }
	}
	
	//AGREGAR RELACI�N ENTRE CALENDARIO CREADO Y USUARIO QUIEN LO CREA
	
	public void RelacionCal(String Email, int ID, String identificacion) {
		
		try {
			this.pstmt = this.Conexion.prepareStatement("INSERT INTO Acceso VALUES(?,?, ?)");
			this.pstmt.setString(1, (String) Email);
			this.pstmt.setInt(2, (int) ID);
			this.pstmt.setString(3, (String) identificacion);
			this.pstmt.executeUpdate();
		} catch (SQLException e) {
				e.printStackTrace();
		} finally {
			try {
				this.pstmt.close();
				this.rs.close();
		} catch (SQLException e) {
				e.printStackTrace();
	 }
   }
		
	}
	
	//BORRAR UN CALENDARIO
	
	public void BorrarCal(int IDC) {
		
		try {
			this.stmt = this.Conexion.createStatement();
			this.stmt.executeQuery("DELETE FROM Calendario WHERE IDCalendario = "+IDC);
		}catch(Exception e) {
			
		}finally {
			try {
				
			}catch(Exception e) {
				
			}
		}
	}
	
	//EDITAR UN CALENDARIO
	
	public void EditarCal(int ID, String Nombre, String Descripcion) {
		try {
			this.pstmt = this.Conexion.prepareStatement("UPDATE Calendario SET NombreCalendario = ? , DescripcionCalendario = ? WHERE IDCalendario = ? ");
			this.pstmt.setString(1, (String) Nombre);
			this.pstmt.setString(2, (String) Descripcion);
			this.pstmt.setInt(3, (int) ID);
			this.pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	//OBTENER LOS NOMBRES DE CALENDARIOS DEL USUARIO
	
	public Object[] VerCalendariosNomb(String Email) {
		Object[] Datos;
		ArrayList<Object> Data = new ArrayList<>();
		try {
			this.stmt = this.Conexion.createStatement();
			this.rs = this.stmt.executeQuery("SELECT NombreCalendario FROM Calendario, Acceso WHERE Calendario.IDCalendario = Acceso.IDCalendario AND Acceso.Email ='"+Email+"'");
			while(rs.next()) {
				Data.add(rs.getString("NombreCalendario"));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				this.stmt.close();
				this.rs.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
		Datos = Data.toArray();
		
		return Datos;
		
	}
	
	public Object[] VerCalendariosID(String Email) {
		Object[] Datos;
		ArrayList<Object> Data = new ArrayList<>();
		try {
			this.stmt = this.Conexion.createStatement();
			this.rs = this.stmt.executeQuery("SELECT Calendario.IDCalendario FROM Calendario, Acceso WHERE Calendario.IDCalendario = Acceso.IDCalendario AND Acceso.Email ='"+Email+"'");
			while(rs.next()) {
				Data.add(rs.getString("IDCalendario"));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				this.stmt.close();
				this.rs.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
		Datos = Data.toArray();
		
		return Datos;
		
	}
	
	//DEVOLVER INFORMACI�N DEL CALENDARIO ESPECIFICO 
	
	
	public String getNombreCal(int IDC) {
		String Nombre = "";
		try {
			this. stmt = this.Conexion.createStatement();
			this.rs = this.stmt.executeQuery("SELECT NombreCalendario FROM Calendario WHERE IDCalendario ="+IDC);
			while(rs.next()) {
				Nombre = rs.getString("NombreCalendario");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return Nombre;
	}
	
	public String getDescripcionCal(int IDC) {
		String Desc = "";
		try {
			this.stmt = this.Conexion.createStatement();
			this.rs = this.stmt.executeQuery("SELECT DescripcionCalendario FROM Calendario WHERE IDCalendario ="+IDC);
			while(rs.next()) {
				Desc = rs.getString("DescripcionCalendario");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return Desc;
	}
	
	
	public Object[] getEventosCal(int ID) {
		Object[] Datos;
		ArrayList<Object> Data = new ArrayList<>();
		try {
			this.stmt = this.Conexion.createStatement();
			this.rs = this.stmt.executeQuery("SELECT * FROM Eventos WHERE Eventos.IDCalendario ="+ID);
			while(rs.next()) {
				Data.add(rs.getString("IDCalendario"));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				this.stmt.close();
				this.rs.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
		Datos = Data.toArray();
		
		return Datos;
		
	}
	
	
}



