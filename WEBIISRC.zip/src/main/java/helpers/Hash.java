package helpers;

import java.security.*;



public class Hash {

	public String Cifrar(String pass) {
		MessageDigest md = null;
		try {
			md = MessageDigest.getInstance("SHA-256");
		}catch(NoSuchAlgorithmException e) {
			e.printStackTrace();
			return null;
		}
		
		byte[] hash = md.digest(pass.getBytes());
		StringBuffer sb = new StringBuffer();
		
		
		for(byte b : hash) {
			sb.append(String.format("%02x", b));
			
		}
		
		return sb.toString();
		
		
		
	}
	
	
	
	
}
