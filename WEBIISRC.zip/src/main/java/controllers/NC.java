package controllers;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import helpers.*;





public class NC {

	static BaseD BD = BaseD.getInstances();
	
	public static String CrearCal(String NombreCal, String DescripcionCal, HttpServletRequest R) {
		
		//SE RECUPERA LA CTA LA CUAL VA A CREAR EL CALENDARIO
		
		HttpSession S = R.getSession();
		String UsuarioC = (String) S.getAttribute("Email");
		String Identificacion = "Propietario";
		
		System.out.println(UsuarioC);
		
		
		int ID = BD.getID();
		
		System.out.println(NombreCal+""+DescripcionCal);
		
		Object[] obj = {ID ,NombreCal, DescripcionCal};
		
		try {
			
			BD.NuevoCalendario(obj);
			BD.RelacionCal(UsuarioC, ID, Identificacion);
			return "{\"mensaje\" : \"Calendario creado exitosamente.\", \"redireccionar\" : \"/AppInicio\",\"estado\":\"200\"}";
			
		}catch(Exception e) {
			
			return "{\"mensaje\" : \"Ha ocurrido un problema al crear su calendario.\", \"redireccionar\" : \"/CrearCalendario\",\"estado\":\"500\"}";
		}
		
		
		
	}
	
	
	
}
