package controllers;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import helpers.*;




public class VisualizarCalendarios {

	private static BaseD BD = BaseD.getInstances();
	
	public static String Calendarios(HttpServletRequest R) {
		
		HttpSession S = R.getSession();
		String UsuarioC = (String) S.getAttribute("Email");
		System.out.println(UsuarioC);
		
		Object[] NombresCal = BD.VerCalendariosNomb(UsuarioC);
		Object[] IDCal = BD.VerCalendariosID(UsuarioC);
		System.out.println(NombresCal.toString() + "" + IDCal.toString());
		
		StringBuilder Respuesta = new StringBuilder();
		Respuesta.append("{\"mensaje\": \"Calendarios retornados\", \"estado\": \"200\", \"IDCaledario\": [");
		for (int i = 0; i < IDCal.length; i++) {
			Respuesta.append("\"" + IDCal[i].toString() +"\",");
		}
		Respuesta = Respuesta.deleteCharAt(Respuesta.length()-1);
		Respuesta.append("], \"NombreCalendario\": [");
		for (int i = 0; i < NombresCal.length; i++) {
			Respuesta.append("\"" + NombresCal[i].toString() +"\",");
		}
		Respuesta = Respuesta.deleteCharAt(Respuesta.length()-1);
		Respuesta.append("]}");
		
		System.out.println(Respuesta.toString());
		
		
		
		return Respuesta.toString();
		
		
	}
	
	
}
