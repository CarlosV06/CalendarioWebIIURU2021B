package controllers;

import helpers.BaseD;

public class BC {

	private static BaseD BD = BaseD.getInstances();
	
	public static String BorrarCalendario(String IDC) {
		
		int ID = Integer.parseInt(IDC);
		
		try {
			BD.BorrarCal(ID);
			return "{\"mensaje\": \"Calendario borrado satisfactoriamente.\", \"estado\": \"200\"}";
		}catch(Exception e) {
			e.printStackTrace();
			return "{\"mensaje\": \"Ha ocurrido un problema borrando el calendario.\", \"estado\": \"500\"}";
		}
	}
	
	
}
