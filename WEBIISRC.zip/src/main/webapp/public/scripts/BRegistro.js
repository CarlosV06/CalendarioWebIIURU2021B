var registerform = document.getElementById("form");
var Boton = document.getElementById("rb");

const SendRegister = (e) =>{
    alert("Este botón está respondiendo...");
    var Form = new FormData(registerform);
    alert(Form.get("fname"));alert(Form.get("email")); alert(Form.get("pass"));
   const parametros = {
       method: 'POST',
       body: Form
       
        
   };
   fetch('RegistroUsuario', parametros).then(respuesta =>{
    return respuesta.json();
    
    }).then(respuesta =>{
        alert(respuesta.message+''+respuesta.status);
        
        });
        
}

Boton.onclick = SendRegister;