var registerform = document.getElementById("form");
var Boton = document.getElementById("login-button");

const SendLogin = (e) =>{
    alert("Este botón está respondiendo...");
    var Form = new FormData(registerform);
    alert(Form.get("email")); alert(Form.get("pass"));
   const parametros = {
       method: 'POST',
       body: Form
   };
   fetch('IniciaSesion', parametros).then(respuesta =>{
    return respuesta.json();
    }).then(respuesta =>{
        alert(respuesta.mensaje+''+respuesta.estado);
        window.location.href = respuesta.redireccionar;
        });
        
}

Boton.onclick = SendLogin;