var BVerUsuario = document.getElementById("BPerfil");
var BEditarUsuario = document.getElementById("editarU");
var BBorrarUsuario = document.getElementById("EliminarU"); 




const VerDatosU = (e) =>{

    fetch("VerUsuario", {
        method: 'GET'
    }).then(respuesta=>{
        respuesta.json();
    }).then(respuesta =>{
        alert("Email: "+respuesta.EmailU + "Nombre y Apellido: "+ respuesta.Nombre+" "+respuesta.Apellido);
    })


}

const EditarDatosU = (e) =>{

    let NuevoNombre = prompt("Nuevo nombre de usuario: ", "NombreUsuario");
    let NuevoApellido = prompt("Nuevo apellido de usuario: ", "ApellidoUsuario");

    let form = new FormData();
    form.append("Nnombre", NuevoNombre);
    form.append("NAp", NuevoApellido);

    fetch("EditarUs",{
        method: 'POST',
        body: form
    }).then(respuesta =>{
        return respuesta.json();
    }).then(respuesta =>{
        if(respuesta.estado == 200){
            window.location.href = "/AppInicio";
        }
    })

}

const BorrarUsuario = (e) =>{

    fetch("BorrarUsu", {
        method: 'DELETE'
    }).then(respuesta =>{
        return respuesta.json();
    }).then(respuesta=>{
        if (respuesta.estado == 200){
            window.location.href = "Inicio.html";
        }
    })




}

BVerUsuario.onclick = VerDatosU;
BEditarUsuario.onclick = EditarDatosU;
BBorrarUsuario.onclick = BorrarUsuario;