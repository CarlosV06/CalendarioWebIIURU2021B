const MostrarCal = () => {
    fetch('VerCalendarios', {method: 'GET'}).then(respuesta =>{
        return respuesta.json();
    }).then(datos =>{
        console.table(datos);
		
        let Panel = document.getElementById("PanelPrincipal");
        for (i = 0; i < datos.IDCaledario.length; i++){
            let calendario = document.createElement('a');
            let BotonVer = document.createElement('button');
            let BotonEditar = document.createElement('button');
            let BotonBorrar = document.createElement('button');
            let BotonAggAct = document.createElement('button');
            calendario.id = datos.IDCaledario[i]+datos.NombreCalendario[i];
            calendario.innerText = datos.NombreCalendario[i];

            BotonEditar.id = datos.IDCaledario[i];
            BotonEditar.innerText = "Editar";
            BotonEditar.style.borderRadius = '20px';
            BotonEditar.style.color = 'dodgerblue';
            BotonEditar.style.backgroundColor = 'white';

            //FUNCIONALIDAD DEL BOTÓN EDITAR

            BotonEditar.onclick = (e) =>{
                let IDC = e.target.id;
                let NuevoNombreC = prompt("Ingresa el nuevo nombre de tu calendario: ", "nombrecalendario");
                let NuevaDes = prompt("Ingresa la nueva información que describe el calendario: ", "descripcion");
                let form = new FormData();
                form.append("IDCaledario", IDC);
                form.append("NNombreC", NuevoNombreC);
                form.append("NDes", NuevaDes);

                fetch('EditarCal', {
                    method: 'POST',
                    body: form
                }).then(respuesta =>{
                    return respuesta.json();
                }).then(datos =>{
                    if(datos.estado == 200){
                        window.location.href = "/AppInicio";
                    }
                })



            }


            BotonBorrar.id = datos.IDCaledario[i];
            BotonBorrar.innerText = "Borrar";
            BotonBorrar.style.borderRadius = '20px';
            BotonBorrar.style.backgroundColor = 'red';

            //FUNCIONALIDAD PARA EL BOTÓN DE BORRAR
            BotonBorrar.onclick = (e) =>{
                let form = new FormData();
                form.append('IDCaledario', e.target.id);

                fetch('BorrarC', {
                    method: 'DELETE',
                    body: form
                }).then(respuesta =>{
                    return respuesta.json();
                }).then(datos =>{
                    console.table(datos);
                    calendario.remove();
                    BotonVer.remove();
                    BotonEditar.remove();
                    BotonBorrar.remove();
                    BotonAggAct.remove();
                    
                })


            }


            BotonAggAct.id = datos.IDCaledario[i];
            BotonAggAct.innerText = "Crear Actividad";
            BotonAggAct.style.borderRadius = '20px';
            BotonAggAct.style.backgroundColor = 'orange';
            BotonAggAct.style.color = 'white';

            BotonVer.innerHTML = "Visualizar";
            BotonVer.id = datos.IDCaledario[i];
            BotonVer.style.borderRadius = '20px';
            BotonVer.style.backgroundColor = 'dodgerblue';
            BotonVer.style.color = 'white';

            //FUNCIONALIDAD PARA EL BOTÓN DE VISUALIZAR
            BotonVer.onclick = (e) =>{
            BotonVer.style.borderRadius = '20px';    
                

                let form = new FormData();
                form.append("IDCaledario", e.target.id);
                for(let value of form.values()){
                    console.log(value);
                }
                fetch("VerCalen", {
                    method: 'POST',
                    body: form
                }).then(respuesta =>{
                    return respuesta.json();
                }).then(datos =>{
                    console.table(datos);
                    
                    let informacion = document.getElementById("MostrarCal");
                    var info = informacion.firstChild;
                    if(info = null){
                    console.log(info);}
                    let label = document.createElement('label');
                    let label2 = document.createElement('label');
                    let divNombre = document.createElement('div');
                    let divDescripcion = document.createElement('div');
                    divNombre.id = "nombre";
                    divDescripcion.id = "descripcion";
                    label.innerText = datos.NombreCale;
                    label2.innerText = datos.DescripcionCale;
                    divNombre.appendChild(label);
                    divDescripcion.appendChild(label2);
                    
                    if (!informacion.hasChildNodes){
                           informacion.appendChild(divNombre);
                           informacion.appendChild(divDescripcion);
                    }else{
                        let ModificarN = document.getElementById("nombre");
                        let ModificarD = document.getElementById("descripcion");
                        informacion.replaceChild(divNombre, ModificarN);
                        informacion.replaceChild(divDescripcion, ModificarD);
                    }
                    

                })
            } 





            

            Panel.appendChild(calendario);
            Panel.appendChild(BotonVer);
            Panel.appendChild(BotonBorrar);
            Panel.appendChild(BotonEditar);
            Panel.appendChild(BotonAggAct);
        }
        
    })

}



window.onload = MostrarCal;