package controllers;

import helpers.BaseD;

public class VC {

	private static BaseD BD = BaseD.getInstances();
	
	public static String getInfo(String ID) {
		
		
		int IDC = Integer.parseInt(ID);
		System.out.println(IDC);
		
		String NombreC = BD.getNombreCal(IDC);
		
		String DescripcionC = BD.getDescripcionCal(IDC);
		
		Object[] Eventos = BD.getEventosCal(IDC);
		
		System.out.println(IDC+"       "+NombreC+"       "+DescripcionC+"          "+Eventos);

		StringBuilder Respuesta = new StringBuilder();
		Respuesta.append("{\"mensaje\": \"Informacion recibida\", \"estado\": \"200\", \"NombreCale\": \""+ NombreC +"\", \"DescripcionCale\": \""+ DescripcionC +"\", \"Eventos\": \"eventox\"");
		//for (int i = 0; i < Eventos.length; i++) {
			//Respuesta.append("\""+ Eventos[i].toString() +"\"");
		//}
		Respuesta.append("}");

		System.out.println(Respuesta.toString());
		
		return Respuesta.toString();
		
	}
	
}
