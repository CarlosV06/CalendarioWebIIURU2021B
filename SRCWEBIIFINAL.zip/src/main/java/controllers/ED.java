package controllers;

import helpers.BaseD;

public class ED {

	private static BaseD BD = BaseD.getInstances();
	
	public static String EditarCal(String IDC, String Nombre, String Descripcion) {
		
		int ID = Integer.parseInt(IDC);
		
		try {
			BD.EditarCal(ID, Nombre, Descripcion);
			return "{\"mensaje\": \"Calendario modificado exitosamente\", \"estado\": \"200\"}";
		}catch(Exception e) {
			
			return "{\"mensaje\": \"No se ha podido editar el calendario\", \"estado\": \"500\"}";
		}
		
		
	}
	
}
