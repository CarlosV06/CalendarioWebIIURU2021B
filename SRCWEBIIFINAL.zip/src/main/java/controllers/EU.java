package controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import helpers.BaseD;

public class EU {

	private static BaseD BD = BaseD.getInstances();
	
	public static String EditarUsuario(String Nombre, String Apellido, HttpServletRequest R) {
		
		HttpSession S = R.getSession();
		String email = (String) S.getAttribute("Email");
		
		
		try {
			BD.EditarU(email, Nombre, Apellido);
			return "{\"mensaje\": \"Usuario editaro correctamente\", \"estado\": \"200\" }";
		}catch(Exception e) {
			e.printStackTrace();
			return "{\"mensaje\": \"Error al editar el usuario\", \"estado\": \"500\" }";
		}
		
		
		
		
		
		
		
	}
	
	
	
	
	
}
