package controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import helpers.BaseD;

public class VUsuario {

	private static BaseD BD = BaseD.getInstances();
	
	public static String getInfoU(HttpServletRequest R) {
		
		HttpSession S = R.getSession();
		String email = (String) S.getAttribute("Email");
		System.out.println(email);
		
		String Nombre_U = BD.NombreU(email);
		String Apellido_U = BD.ApellidoU(email);
		
		
		try {
			
			StringBuilder respuesta = new StringBuilder();
			respuesta.append("{\"mensaje\": \"Informaci�n recibida exitosamente.\", \"estado\": \"200\", \"NombreUsuario\": \""+Nombre_U+"\", \"ApellidoUsuario\": \""+Apellido_U+"\", \"Correo\": \""+email+"\"}");
			return respuesta.toString();
		}catch(Exception e) {
			return "{\"mensaje\": \"Error; la informacion no fue obtenida\", \"estado\": \"500\"}";
		}
		
		
		
		
	}
	
	
	
}
