package controllers;

import helpers.BaseD;

public class NE {

	private static BaseD BD = BaseD.getInstances();
	
	public static String AddEvento(String IDC, String Nombre, String Descripcion, String Fecha, String Hora, String img) {
		
		int IDCalendario = Integer.parseInt(IDC);
		int IDEvento = BD.getIDE();
		
		try {
			
			BD.NuevoEvento(IDEvento, IDCalendario, Nombre, Descripcion, Fecha, Hora, img);
			return "{\"mensaje\": \"Evento creado satisfactoriamente\", \"estado\": \"200\"}";
			
			
		}catch(Exception e) {
			e.printStackTrace();
			return "{\"mensaje\": \"Error al crear la actividad\", \"estado\": \"500\"}";
		}
		
		
		
		
		
	}
	
}
