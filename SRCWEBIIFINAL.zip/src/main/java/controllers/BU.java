package controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import helpers.BaseD;

public class BU {

	private static BaseD BD = BaseD.getInstances();
	
	public static String BorrarUsuarioBD(HttpServletRequest R) {
		
		HttpSession S = R.getSession();
		String email = (String) S.getAttribute("Email");
		
		try {
			BD.BorrarU(email);
			return "{\"mensaje\": \"Usuario borrado\", \"estado\": \"200\"}";
		}catch(Exception e) {
			e.printStackTrace();
			return "{\"mensaje\": \"Error al borrar el usuario\", \"estado\": \"500\"}";
		}
		
		
	}
	
	
}
