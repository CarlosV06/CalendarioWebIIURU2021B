package controllers;

import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import helpers.*;


public class LC {

	
	
	
	
	public static String IniciarSesion(HttpServletRequest R) {
		Autenticar a = new Autenticar();
		
		try {
			if(a.ValidarCredenciales(R.getParameter("email"), R.getParameter("pass")) == true ) {
				HttpSession sesion = R.getSession();
				sesion.setAttribute("Email", R.getParameter("email"));
				return "{\"mensaje\" : \"Sesi�n iniciada exitosamente.\", \"redireccionar\" : \"/AppInicio\",\"estado\":\"200\"}";
				
			}else {
				return "{ \"mensaje\" : \"Error al iniciar sesi�n. Credenciales erradas.\", \"estado\" : \"500\", \"redireccionar\" : \"/RInicioS\"}";
			}			
		}catch(Exception e) {
			e.printStackTrace();
			return "{ \"mensaje\" : \"Error al iniciar sesi�n.\", \"estado\" : \"500\", \"redireccionar\" : \"/RInicioS\"}";
		}
	}
	
	
	
}
