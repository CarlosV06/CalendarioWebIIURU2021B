package controllers;


import helpers.BaseD;
import helpers.Hash;
import helpers.ProperR;

public class RC {
	    private static BaseD DB = BaseD.getInstances();

	    public static String register(String fname, String lname, String email, String pass) {

	        System.out.println( fname +"   "+lname+"   "+ email + "   " + pass );
	        
	        Hash H = new Hash();
	        String HPass = H.Cifrar(pass);
	        System.out.println(HPass);
	        Object[] obj = {email, fname, lname, HPass};
	        
	        try {
	            DB.dbPrepareStatement("INSERT INTO Usuarios VALUES (?, ?, ?, ?)", obj);
	            //MODIFICA EL M�TODO EN LA CLASE BD PARA ADMITIR LOS 4 DATOS.

	            return "{\"message\": \"usuario creado\", \"status\": 200 }";
	        }catch (Exception e) {
	            // TODO: handle exception
	           return"{\"mensaje\": \"el usuario ya existe.\", \"estado\": 503 }";
	        }
			
	    }

		

	}

