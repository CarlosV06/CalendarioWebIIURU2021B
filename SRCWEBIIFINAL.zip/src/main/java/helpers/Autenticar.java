package helpers;
import helpers.Hash;



public class Autenticar {

	BaseD BD = BaseD.getInstances();
	//ProperR PR = ProperR.getInstances();

	
	
	public boolean ValidarCredenciales(String Correo, String Pass) {
		
		System.out.println(Correo+"  "+Pass);
		
		
		
		boolean Validez = false;
		
		//SE ENCRIPTA LA CLAVE RECIBIDA POR EL USUARIO
		
		Hash H = new Hash();
		String PassCifrada = H.Cifrar(Pass);
		
		//VERIFICAMOS LA COINCIDENCIA DE LOS DATOS EN LA BD
		
		String ClaveBD = BD.getClave(Correo, "SELECT * FROM Usuarios");
			
		String ClaveU = PassCifrada;
		
		
		if(ClaveU.equals(ClaveBD)) {
			Validez = true;
		}else {
			System.out.println("Datos incorrectos, los datos no coinciden con ninguna cuenta.");
			Validez = false;
		}
		
		
		
		return Validez;
		
		
		
		
	}
	
	
	
	
	
}
