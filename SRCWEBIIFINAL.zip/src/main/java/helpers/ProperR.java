package helpers;

import java.io.*;
import java.util.*;


public class ProperR {

	//ATRIBUTOS
	private static ProperR Pr = new ProperR();
	private File Archivo;
	private FileInputStream FIS;
	private Properties propiedades;
	
	private String DatosBD[];
	private String SentenciasBD[];
	
	//CONSTRUCTOR
	
	public ProperR() {
		
		//CREANDO OBJETO FILE CON RUTA AL ARCHIVO DE PROPIEDADES
		
		Archivo = new File("C:\\Users\\Luis Paul\\eclipse-workspace\\Proyecto I Web II\\src\\main\\java\\helpers\\ConfiguracionBD.Properties");
		
		//UBICANDO ARCHIVO PROPERTIES
		
		try {
			FIS = new FileInputStream(Archivo);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//CREANDO OBJETO PROPERTIES Y CARGANDO LA INFORMACI�N
		
		propiedades = new Properties();
		
		try {
			propiedades.load(FIS);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}
	
	
	public static ProperR getInstances() {
		return Pr;
	}
	
	public String getDato(String dato) {
		return propiedades.getProperty(dato);
	}
	
}
