var registerform = document.getElementById("form");
var Boton = document.getElementById("CC");


const SendData = () =>{
    alert("Procesando información");
    var Form = new FormData(registerform);


    var parametros = {
        method: 'POST',
        body: Form
    };

    fetch('CrearC', parametros).then(respuesta =>{
        return respuesta.json();
        }).then(respuesta =>{
            alert(respuesta.mensaje+''+respuesta.estado);
            window.location.href = respuesta.redireccionar;
            });

}

Boton.onclick = SendData;