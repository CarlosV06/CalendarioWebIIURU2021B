
//FUNCIÓN PARA MOSTRAR LOS DATOS DEL USUARIO ANTES DE CARGAR EL HTML

const VerDatos = (e) =>{

    fetch("VerUsuario",{
        method: 'GET'
    }).then(respuesta => {
        return respuesta.json();
    }).then(respuesta => {
        let div = document.getElementById("DatosU");
        let etiqueta = document.createElement('h1');
        etiqueta.id = "datos";
        etiqueta.innerText = "Información de la cuenta: ";
        let ENombre = document.createElement('label');
        let salto = document.createElement('br');
        let salto2 = document.createElement('br');
        let salto3 = document.createElement('br');
        let EApellido = document.createElement('label');
        let ECorreo = document.createElement('label');

        ENombre.id = respuesta.NombreUsuario;
        ENombre.innerText = respuesta.NombreUsuario;
        EApellido.id = respuesta.ApellidoUsuario;
        EApellido.innerText = respuesta.ApellidoUsuario;
        ECorreo.id = respuesta.Correo;
        ECorreo.innerText = respuesta.Correo;

        div.appendChild(etiqueta);
        div.appendChild(salto3);
        div.appendChild(ENombre);
        div.appendChild(salto);
        div.appendChild(EApellido);
        div.appendChild(salto2);
        div.appendChild(ECorreo);
    })

}

window.onload = VerDatos;




