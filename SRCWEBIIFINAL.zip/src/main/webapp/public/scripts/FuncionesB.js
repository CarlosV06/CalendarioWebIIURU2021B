var BotonBU = document.getElementById("BorrarU");
var BotonEU = document.getElementById("EditarU");

const BorrarUsuario = (e) =>{
    fetch("BorrarUsuario", {
        method: "DELETE"
    }).then(respuesta =>{
        return respuesta.json();
    }).then(respuesta =>{
        if (respuesta.estado == 200){
            window.location.href = "Inicio.html";
        }
    })
}

const EditarUsuario = (e) =>{
    let NuevoNombre = prompt("Ingresa el nuevo nombre: ", "Nombre");
    let NuevoApellido = prompt("Ingresa el nuevo apellido: ", "Apellido");

    let form = new FormData();
    form.append("NU", NuevoNombre);
    form.append("AU", NuevoApellido);

    fetch("EditarU", {
        method: 'POST',
        body: form
    }).then(respuesta =>{
        return respuesta.json();
    }).then(respuesta =>{
        if (respuesta.estado == 200){
            window.location.href = "VerU";
        }
    })
}

BotonBU.onclick = BorrarUsuario;
BotonEU.onclick = EditarUsuario;